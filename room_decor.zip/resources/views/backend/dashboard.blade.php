@extends('admin_layout')

@section('content')
    <!-- //market-->
    <p>Chào bạn đến với trang admin !!!</p>
@endsection
