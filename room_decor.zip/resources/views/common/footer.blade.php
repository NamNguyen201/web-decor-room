<footer class="footer">
          <!-- Grid container -->
            <div class="row ">
              <!--Grid column-->
              <div class=" row1 col-md-4 align-self-center  col1 ">             
                <ul class="  list-unstyled mb-0 ">
                    <div class="li1">
                        <li>
                            <a href="#!" class="text-dark">ABOUT</a>
                        </li>
                        <li>
                            <a href="#!" class="text-dark">BEDROOM</a>
                        </li>
                        <li>
                            <a href="#!" class="text-dark">LIVING ROOM</a>
                        </li>
                        <li>
                            <a href="#!" class="text-dark">KITCHEN</a>
                        </li>
                        <li>
                            <a href="#!" class="text-dark">BABIES</a>
                        </li>
                          
                    </div>
                    <div class="li2">
                        <li>
                            <a href="#!" class="text-dark">THE NEW</a>
                        </li>
                        <li>
                            <a href="#!" class="text-dark">CONTACT</a>
                        </li>
                        <li>
                            <a href="#!" class="text-dark">MEMBERSHIP</a>
                        </li>
                    </div>
                  
                </ul>
              </div>
              <!--Grid column-->

              <!--Grid column-->
              <div class=" col-md-4 align-self-center col2">
                <ul class="list-unstyled">
                  <li>
                    <p class="footer-p1">Do you want to receive news <br> of promotions and new products? <br> Sign up for our newsletter now </p>
                  </li>
                  <li>                  
                    <form  action="">
                      <div class="mb-3">
                        <input type="email" placeholder="" class="form-control">
                      </div>
                      <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">SIGNUP</button>
                      </div>
                    </form>     
                  </li>
                  <li>
                    <p class="footer-p2">Lorem ipsun dolor sit met, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi  enim ad minim veniam, quis nostrud exenci tation</p>
                  </li>
                 
                </ul>
              </div>
              <!--Grid column-->

              <!--Grid column-->
              <div class=" col-md-4 align-self-center col3">           
                <ul class="list-unstyled mb-0 ">
                  <li>
                    <p class="footer-p3">SOLUTIONS FOR EVERY DAY</p>
                  </li>
                  <li>
                    <p class="footer-p4">MY HOME</p>
                  </li>
                  <li>
                    <img src="{{('frontend/image/group9/slogan.png')}}" class="img-fluid">
                  </li>
                  
                </ul>
              </div>
              <!--Grid column-->

              
            </div>
            <!--Grid row-->
                  
        </footer>