<div class ="header ">
    <ul class="header-heading">
        <p class="header-heading--h">MY HOME</p>
    </ul>
    <ul class="header-heading1">
        <p class="header-heading1--h1">SOLUTION FOR EVERY DAY</p>
    </ul>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container-fluid ">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
           <span class="navbar-toggler-icon"></span>
       </button>
       <div class="collapse navbar-collapse " id="navbarSupportedContent">
        <ul class="navbar-nav mb-2 mb-lg-0 ">
            <li class="nav-item">
              <a class="nav-link active " aria-current="page" href="#">ABOUT</a>
          </li>
          <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="#">BEDROOM</a>
          </li>
          <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="#">LIVING ROOM</a>
          </li>
          <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="#">KITCHEN</a>
          </li>
          <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="#">BABIES</a>
          </li>
          <li class="nav-item">
            <img class="nav-img active" src = "{{('frontend/image/group1/Subtitle.png')}}" />
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">THENEW</a>
      </li>
      <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">CONTACT</a>
      </li>
      <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">MEMBERSHIP</a>
      </li>
      <li class="nav-item">
        <form action="">
            <input class="form-control me-2" type="search" placeholder="SEARCH" aria-label="Search">
        </form>
    </li>
</ul>

</div>
</div>
</nav>
<ul class="header-heading2">
    <p class="header-heading2--h2">FREE SHIPPING OVER $70 DISSCOUNT ALL OUR ONLINE STORE</p>
</ul>
<div class="banner" >


    <img src="{{('frontend/image/group1/image.png')}}" class="img-fluid" alt="...">
    <form  action="" class="signup-form">
      <div class="mb-3">
        <input type="email" placeholder="EMAIL" class="form-control">
    </div>
    <button type="submit" class="btn btn-primary">SIGNUP</button>
</form>

</div>

</div>
